package br.com.clovis.denilson_bonatti;

import br.com.clovis.thiago_leite_e_carvalho.order.Order;

public class MyFirstProgram {
    public static void main(String[] args) {
        final Order order = new Order("codel1234");
        System.out.println(order);
    }
}
