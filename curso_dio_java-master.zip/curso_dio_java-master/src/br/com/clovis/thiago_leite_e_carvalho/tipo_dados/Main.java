package br.com.clovis.thiago_leite_e_carvalho.tipo_dados;

public class Main {
    public static void main(String[] args) {
        byte b1 = 10;//0
        byte b2 = 20;//0
        short s1 = 20000;//0
        //short s2 = 40000;//0
        //int i1 =  -10000000000;//0
        int i2 =  28580;//0
        long l1 = 1000000000000000000L;//0L
        long l2 = 2000000000000000000L;//0L
        //float f1 = 4.5;//0.0f
        float f2 = 10.68f;//0.0f
        double d1 = 85.69;//0.0d
        double d2 = 99.64d;//0.0d
        char c1 = 't';//null
        //char c2 = "t";//null
        char c3 = '\u0057';//|u000
        String st1 = "Fulano";//null
        String st2 = "Ciclano";//null
        //String st3 = "09/03/2021";//null
        boolean bo1 = true;//false
        boolean bo2 = false;//false
        System.out.println(b1);
        System.out.println(b2);
        System.out.println(s1);
        System.out.println(i2);
        System.out.println(l1);
        System.out.println(l2);
        System.out.println(f2);
        System.out.println(d1);
        System.out.println(d2);
        System.out.println(c1);
        System.out.println(c3);
        System.out.println(st1);
        System.out.println(st2);
        System.out.println(bo1);
        System.out.println(bo2);
    }
}
