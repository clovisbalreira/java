package br.com.clovis.thiago_leite_e_carvalho.laco_while;

public class WhileClassico {
    public static void main(String[] args) {
        int count = 0;
        while (count < 3){
            System.out.println("O valor do count é " + count);
            count++;
        }
    }
}
