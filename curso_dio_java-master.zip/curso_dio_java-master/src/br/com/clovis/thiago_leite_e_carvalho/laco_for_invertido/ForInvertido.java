package br.com.clovis.thiago_leite_e_carvalho.laco_for_invertido;

public class ForInvertido {
    public static void main(String[] args) {
        for( int i = 10; i > 0; i--){
            System.out.println("O valor de i é " + i);
        }
    }
}
