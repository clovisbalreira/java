package br.com.clovis.thiago_leite_e_carvalho.laco_for;

public class ForClassico {
    public static void main(String[] args) {
        for(int i = 0; i < 10; i++){
            System.out.println("O valor de i é " + i);
        }
    }
}
