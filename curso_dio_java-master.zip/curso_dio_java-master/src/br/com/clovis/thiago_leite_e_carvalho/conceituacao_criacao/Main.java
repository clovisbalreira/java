package br.com.clovis.thiago_leite_e_carvalho.conceituacao_criacao;

public class Main {
    public static void main(String[] args) {
        int i;
        //int i;
        int I;
        //int 1;
        int _1a;
        int Saq;

        i = 5;
        I = 10;
        _1a = 20;
        Saq = 7;

        final int j = 10;
        //j = 15;
        int asrn24675ad;
        //int asrn24 45;
        int asrn24675_ad = 10;
        //int asrn2467%5_ad;

        asrn24675ad = 100;
        asrn24675_ad = 10;

        int quantidadeProduto = 50;
        //int QuantidadeProduto;
        final int NUMBER_TENTATIVA = 5;
        //final int numeroTentativa = 1;
        int QUANTIDADE_OPCOES = 25;
        int qtdProd;

        System.out.println(i);
        System.out.println(I);
        System.out.println(_1a);
        System.out.println(Saq);

        System.out.println(j);
        System.out.println(asrn24675ad);
        System.out.println(asrn24675_ad);

        System.out.println(quantidadeProduto);
        System.out.println(NUMBER_TENTATIVA);
        System.out.println(QUANTIDADE_OPCOES);

    }
}
