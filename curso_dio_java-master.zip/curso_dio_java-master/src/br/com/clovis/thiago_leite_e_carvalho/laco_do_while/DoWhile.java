package br.com.clovis.thiago_leite_e_carvalho.laco_do_while;

public class DoWhile {
    public static void main(String[] args) {
        int count = 0;
        do {
            System.out.println("O valor do count é " + count);
            count++;
        }while (count < 10);
    }
}
