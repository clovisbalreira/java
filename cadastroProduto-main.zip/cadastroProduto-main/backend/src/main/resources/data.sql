INSERT INTO product (code_product,name,price) VALUES (null, 'Banana', 1.99);
INSERT INTO product (code_product,name,price) VALUES (null, 'Tomate', 1.50);