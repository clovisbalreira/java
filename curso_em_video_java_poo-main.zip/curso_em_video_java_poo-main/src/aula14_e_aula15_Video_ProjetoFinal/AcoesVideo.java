package aula14_e_aula15_Video_ProjetoFinal;

public interface AcoesVideo {
    public abstract void play();
    public abstract void pause();
    public abstract void like();
}
