package aula13_Animal_polimorfismo_sobrecarga;

public class Lobo extends Mamifero{
    @Override
    public void emitirSom(){
        System.out.println("Auuuuuuuuuuuuu!");
    }
}
