package aula11_Pessoa_HerancaTipo;

public class Visitante extends Pessoa{
}
