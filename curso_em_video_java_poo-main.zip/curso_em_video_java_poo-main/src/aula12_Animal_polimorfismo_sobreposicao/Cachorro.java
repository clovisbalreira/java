package aula12_Animal_polimorfismo_sobreposicao;

public class Cachorro extends Mamifero{
    public void EnterrarOsso(){
        System.out.println("Enterrando o osso");
    }
    public void AbanarRabo(){
        System.out.println("Abanando o rabo");
    }
}
