package aula12_Animal_polimorfismo_sobreposicao;

public class Goldfish extends Peixe{
}
