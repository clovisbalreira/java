package aula12_Animal_polimorfismo_sobreposicao;

public class Cobra extends Reptil{
}
