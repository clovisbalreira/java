package aula12_Animal_polimorfismo_sobreposicao;

public class Tartaruga extends Reptil{
    @Override
    public void Locomover(){
        System.out.println("Andando bem devagar");
    };
}
