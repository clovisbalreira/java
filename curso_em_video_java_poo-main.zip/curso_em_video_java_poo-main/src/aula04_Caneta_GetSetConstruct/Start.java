package aula04_Caneta_GetSetConstruct;

public class Start {
    public static void main(String[] args){
        Caneta c1 = new Caneta("BIC","Azul",0.5f);
        c1.status();
    }
}
